import ExamPP.Packet

import scala.annotation.tailrec

object ExamPP {

  def profileID = 568448 // Aici va trebui sa puneti ID-ul vostru de pe moodle

  /*
  * Vom defini TDA-ul `Packet` care va avea foi constructori `UDP` si `TCP`.
  */
  trait Packet
  case class UDP(port: Int) extends Packet
  case class TCP(port: Int) extends Packet

  /*
  * Definim un ACL (Access Control List) ca fiind o lista de predicate.
  * Un pachet este acceptat de un ACL daca toate predicatele din lista sunt adevarate, altfel este respins.
  */
  type ACL = List[Packet => Boolean]

  /*
  * EXERCITIUL 1
  * Scrieti o funtie care primeste o secventa de pachete `p1, ... pn` si un ACL si
  * returneaza o subsecventa (posibil vida) de pachete `p1, ... pk-1` astfel incat `pk`
  * este primul pachet din secventa care este respins de ACL, cu 1 <= k <= n.
  */
  def acceptSequence(packets: List[Packet], acl: ACL): List[Packet] = {
    def acl_verify(packet: Packet): Boolean = {
      acl.map(func => func(packet)).reduce((x,y) => x && y)
    }
    @tailrec
    def aux_accept(k:Int, accepted: List[Packet], packets: List[Packet]): List[Packet] = {
      if (packets == List()) return accepted
      if (acl_verify(packets.head) && k == 0)  aux_accept(0, accepted :+ packets.head, packets.tail)
      else aux_accept(1, accepted, packets.tail)
    }
    aux_accept(0, List(), packets)
  }

  /*
  * EXERCITIUL 2
  * Scrieti o functie care primeste un ACL si transforma lista de predicate intr-un singur predicat.
  * Mai precis, creati un predicat care returneaza true pentru fiecare pachet permis de ACL, si false,
  * in caz contrar. Hint: folositi fold.
  */
  def foldACL(acl: ACL): Packet => Boolean = {
    def fold_helper(f:Packet => Boolean)(g:Packet => Boolean): Packet => Boolean =
      x => f(x) && g(x)
    acl.reduce((x,y) => fold_helper(x)(y))
  }

  /*
  * EXERCITIUL 3
  * Scrieti o functie care primeste doua ACL-uri si verifica daca sunt echivalente peste setul
  * de pachete UDP cu porturi intre 0 si 10.
  * Doua ACL-uri sunt echivalente daca au aceeasi comportament (accepta sau resping aceleasi pachete).
  */
  def equivalentUDP10(acl1: ACL, acl2: ACL): Boolean = ???

  /*
  * Vom defini tipul `Product` ca avand un nume si un pret.
  * Un `ShoppingList` este o pereche formata din numele unui client si o lista de nume de produse
  * pe care acesta doreste sa le cumpere.
  */

  type Price = Float
  type ProductName = String
  type Product = (ProductName, Price)
  type CustomerName = String
  type ShoppingList = (CustomerName, List[ProductName])

  /*
  * EXERCITIUL 4
  * Se considera ca pretul listei de cumparaturi a unui client este suma preturilor produselor din lista sa.
  * Pentru mai multe liste de cumparaturi, calculati pretul fiecareia.
  */
  def shoppingListPrices(shoppingLists: List[ShoppingList], productInventory: List[Product]): List[(CustomerName, Price)] = {
    shoppingLists.map( (x,y) => (x, y.map(name => productInventory
      .find((pname, price) => pname == name).get._2).sum()))
  }
  /*
  * EXERCITIUL 5
  * Scrieti o functie care primeste o lista de valori intregi "boxed" intr-un container de tip Option:
  * un "container" este fie gol, fie contine un intreg.
  * Functia ar trebui sa returneze o lista "boxed" de intregi, daca TOATE "containerele" care nu sunt goale
  * contin un intreg strict pozitiv, si None, in caz contrar.
  */
  def positiveValues(l: List[Option[Int]]): Option[List[Int]] = {
    @tailrec
    def aux_helper(createdListL: List[Int], l1: List[Option[Int]]): Option[List[Int]] = {
      if (l1.isEmpty) return Some(createdListL)
      else l1.head match {
        case None => aux_helper(createdListL, l1.tail)
        case Some(x) => if (x < 0) None
        else aux_helper(createdListL :+ x, l1.tail)
      }
    }
    aux_helper(List(), l)
  }
}